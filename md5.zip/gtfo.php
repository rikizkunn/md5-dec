<?php
require __DIR__ . '/vendor/autoload.php';
$climate = new League\CLImate\CLImate;
use \Curl\MultiCurl;

/*
      14-03-2020
      Coded by Rzyz Gavini
      Reference by Mukhlis Akbar
      fb.me/rikizkun
*/

function chk($lines){          
$multi_curl = new MultiCurl();
$multi_curl->setRetry(function ($instance){ 
$max_retries=5;
return $instance->retries<$max_retries;
});
$multi_curl->success(function ($instance) {    
      $rezl = $instance->email."|".$instance->response;
      $rezd = $instance->email."|".$instance->pass;
      $climate = new League\CLImate\CLImate; 
      if(empty($instance->response))
      {
            
            $climate->out("<blue>[ MD5 DECRYPT UwU ]</blue> - <light_yellow>[ ".date("h:i:s")." ]</light_yellow> - <light_red>LIVE $rezd </light_red>");
            saveFuckinResult('Result/DIE.txt', $rezd);
      } else {         
            $climate->out("<blue>[ MD5 DECRYPT UwU ]</blue> - <light_yellow>[ ".date("h:i:s")." ]</light_yellow> - <light_green>LIVE $rezl </light_green>");
            saveFuckinResult('Result/LIVE.txt', $rezl);
 
 
   } 
});
$multi_curl->error(function ($instance) {
    echo 'call to "' . $instance->url . '" was unsuccessful.' . "\n";
    echo 'error code: ' . $instance->errorCode . "\n";
    echo 'error message: ' . $instance->errorMessage . "\n";
    echo 'PLEASE CONTACT DEV AT fb.me/rikizkun';
});


foreach($lines as $meki){
list($email, $pass) = explode("|", $meki);
$instance = $multi_curl->addGet('http://www.nitrxgen.net/md5db/'.$pass);
$instance->email = $email;
$instance->pass = $pass;
}

$multi_curl->start();
}

function saveFuckinResult ($files, $res) {
    $file = fopen($files, 'a');
    fwrite($file, $res ."\n");
    fclose($file);
}

$climate->clear();

$climate->addArt('vendor/anim');
$climate->blue()->animation('anim')->enterFrom('left');

$empass = $climate->input('[?] Enter List ?')->prompt(); 
if(file_exists($empass)){
$lines = file($empass, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $lines = array_map('trim',$lines);
    $lines = array_unique($lines);
    file_put_contents($empass, implode(PHP_EOL, $lines));
$clear = $climate->confirm('[!] Clear Result ?');
if ($clear->confirmed()) {
    file_put_contents('Result/LIVE.txt', "");
    file_put_contents('Result/DIE.txt', ""); 
}
$climate->out("[+] ".count(file($empass))." List Ready To Decrypt [+]</light_green>");
$climate->out("<light_red>[+] DECRYPTOR STARTED [+]</light_red>");
sleep(2);
$climate->clear();
$time_s = microtime(true);
chk($lines);
$time_e = microtime(true);
$time = $time_e - $time_s;
$climate->br();
$climate->out("<light_green>[ LIVE : ".count(file('Result/LIVE.txt'))." ]</light_green> - <light_red>[ DIE : ".count(file('Result/DIE.txt'))." ]</light_red> -><light_yellow> ".count(file($empass))." List Complete in $time");
$climate->out("<blue>Check /Result Folder</blue>");

} else {
      $climate->out("<light_red>[!] CHECK YOUR FILE AGAIN! [!] </light_red>");
}